// Mobile view if you have a diffrent page that you want to show users that are on mobile than add it into location.replace("");

/*if(navigator.userAgent.match(/iPad|iPhone|Android|BlackBerry|Windows Phone|webOS/i)){
  location.replace("");
}*/

// Open navigation
function openNav(){
  document.getElementById("mySidenav").style.width = "100%";
}
function closeNav(){
  document.getElementById("mySidenav").style.width = "0";
}

// Contact us add links just copy url[0] = ""; but put a 1, 2, 3 and so on inside the [] the top one has to be zero because this is an array and arrays start at 0 not 1
function newPage(num){
  var url = new Array();
  url[0] = "";
  window.location=url[num];
}

document.addEventListener('DOMContentLoaded', function() {
    var $navbarBurgers = Array.prototype.slice.call(document.querySelectorAll('.navbar-burger'), 0);
        if ($navbarBurgers.length > 0) {
            $navbarBurgers.forEach(function($el) {
                $el.addEventListener('click', function() {
                    var target = $el.dataset.target;
                    var $target = document.getElementById(target);
                    $el.classList.toggle('is-active');
                    $target.classList.toggle('is-active');
                });
            });
        }
    });
    
    function switchToiOS() {
        removeActive();
        hideAll();
        $("#ios-tab").addClass("is-active");
        $("#ios-tab-content").removeClass("hidden");
    }
    
    function switchToAndroid() {
        removeActive();
        hideAll();
        $("#android-tab").addClass("is-active");
        $("#android-tab-content").removeClass("hidden");
    }
    
    function switchToGame() {
        removeActive();
        hideAll();
        $("#game-tab").addClass("is-active");
        $("#game-tab-content").removeClass("hidden");
    }
    
    function switchToWeb() {
        removeActive();
        hideAll();
        $("#web-tab").addClass("is-active");
        $("#web-tab-content").removeClass("hidden");
    }
    
    function removeActive() {
        $("li").each(function() {
            $(this).removeClass("is-active");
        });
    }
    
    function hideAll() {
        $("#ios-tab-content").addClass("hidden");
        $("#android-tab-content").addClass("hidden");
        $("#game-tab-content").addClass("hidden");
        $("#web-tab-content").addClass("hidden");
    }